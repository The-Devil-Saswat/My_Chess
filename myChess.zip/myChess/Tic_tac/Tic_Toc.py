import pygame


pygame.init()
width = 800
height = 600
screen =  pygame.display.set_mode([width,height])
pygame.display.set_caption('TIC TOC GAME')
timer = pygame.time.Clock()
fps = 60
run = True
while run:
    timer.tick(fps)
    screen.fill('grey')
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run=False
    pygame.display.flip()
pygame.quit()
    
